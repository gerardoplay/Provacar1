package com.example.peppelt.provacar1;

public interface OnOkPressedDialogPicker {

	public void onDialogDateOkPressed(int anno, int mese, int giorno);

	public void onDialogTimeOkPressed(int ore, int minuti);
}
