package com.example.peppelt.provacar1;

public interface RemoteCallListener<E> {
	void onRemoteCallListenerComplete(E dati);
}
